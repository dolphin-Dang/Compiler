#ifndef CODE_CONFIG_H
#define CODE_CONFIG_H

#define YYERROR_OUTPUT stderr

#define IR_IN_APPEND_EOL 1

#endif //CODE_CONFIG_H
